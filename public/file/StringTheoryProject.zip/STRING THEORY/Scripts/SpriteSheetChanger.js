var down:Material;
var up:Material;
var left:Material;
var right:Material;
var idle:Material;

var current:Material;
private var prev:Material;

function Update() 
{
	var v = Input.GetAxisRaw("Vertical");
	var h = Input.GetAxisRaw("Horizontal");
	
	if(Mathf.Abs(h) > Mathf.Abs(v))
	{
		if(h < -0.2) current = left;
		else if(h > 0.2) current = right;
	}
	else if(Mathf.Abs(v) > Mathf.Abs(h))
	{
		if(v < -0.2) current = down;
		else if(v > 0.2) current = up;
	}
	else if(v > -0.2 && v < 0.2 && h > -0.2 && h < 0.2) current = idle;
	
	
	if(prev != current) renderer.material = current;
	prev = current;
}
