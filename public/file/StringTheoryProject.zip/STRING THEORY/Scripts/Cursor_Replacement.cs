﻿using UnityEngine;
using System.Collections;

public class Cursor_Replacement : MonoBehaviour {
	public GameObject cursorImage;
	public GameObject growingCursor;
	private float arrowlocationx;
	private float arrowlocationy;
	private float power;
	private Vector3 mousePos; 

	public void Start() 
	{
		Screen.showCursor = false;
		growingCursor.SetActive(false);
		power = 0;

	}

	public void Update()
	{
		mousePos = Camera.main.ScreenToWorldPoint (Input.mousePosition);
		//When mouse(left) is held down, charge

		//(if hasball)

		if(Input.GetMouseButton(0))
		{
			if(!Input.GetMouseButton(1))
			{
				if(power <= 500)
				{
					power += Time.deltaTime * 1000;
				}
				growingCursor.SetActive(true);

				growingCursor.transform.localScale = new Vector3(power/500, power/500, 1);
				growingCursor.transform.position = mousePos + new Vector3(0,0, 11);

			}
			else
			{
				power = 0;
			}
		}
		else
		{
			power = 0;
			growingCursor.SetActive(false);

		}

		//end if(hasball)

		cursorImage.transform.position = mousePos + new Vector3(0,0, 11);

	}
	



}
