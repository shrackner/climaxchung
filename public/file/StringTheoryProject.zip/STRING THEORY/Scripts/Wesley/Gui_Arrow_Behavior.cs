﻿using UnityEngine;
using System.Collections;

public class Gui_Arrow_Behavior : MonoBehaviour {
	public Texture arrow;
	public GameObject camera;
	public GameObject fish;
	private float angle;
	private float distanceX;
	private float distanceY;
	private float screenDiagAngle;
	private float screenWidth;
	private float screenHeight;

	// Use this for initialization
	void Start ()
	{
		screenDiagAngle = Mathf.Atan2(Screen.height,Screen.width);
		screenWidth = Screen.width;
		screenHeight = Screen.height;
	}

	void OnGUI()
	{
		if(!fish.renderer.isVisible)
		{
			distanceX = fish.transform.position.x - camera.transform.position.x;
			distanceY = fish.transform.position.y - camera.transform.position.y;
			angle = Mathf.Atan2(distanceX,distanceY);
			

			
			//right side
			if((angle > Mathf.PI/2 - screenDiagAngle) && (angle < Mathf.PI/2 + screenDiagAngle))
			{
				float extra = screenWidth/2/distanceX * distanceY;
				Rect positionArrow = new Rect(screenWidth - arrow.width,
				                              screenHeight/2 - extra - arrow.height/2,
				                              arrow.width,
				                              arrow.height);
				GUIUtility.RotateAroundPivot(angle/Mathf.PI*180 - 90, new Vector2(positionArrow.x,positionArrow.y));
				GUI.Label(positionArrow,arrow);
			}
			
			//top side
			if(((angle > 0) && (angle < Mathf.PI/2 - screenDiagAngle)) || ((angle < 0) && (angle > screenDiagAngle - Mathf.PI/2)))
			{
				float extra = screenHeight/2/distanceY * distanceX;
				Rect positionArrow = new Rect(screenWidth/2 + extra + arrow.width/2,
				                              arrow.width,
				                              arrow.width,
				                              arrow.height);
				GUIUtility.RotateAroundPivot(angle/Mathf.PI*180 - 90, new Vector2(positionArrow.x,positionArrow.y));
				GUI.Label(positionArrow,arrow);
			}
			
			//left side
			if((angle < screenDiagAngle - Mathf.PI/2) && (angle > -Mathf.PI/2 - screenDiagAngle))
			{
				float extra = screenWidth/2/distanceX * distanceY;
				Rect positionArrow = new Rect(arrow.width,
				                              screenHeight/2 + extra + arrow.height/2,
				                              arrow.width,
				                              arrow.height);
				GUIUtility.RotateAroundPivot(angle/Mathf.PI*180 - 90, new Vector2(positionArrow.x,positionArrow.y));
				GUI.Label(positionArrow,arrow);
			}
			
			//bottom side
			if(((angle < Mathf.PI) && (angle > Mathf.PI/2 + screenDiagAngle)) || ((angle > -Mathf.PI) && (angle < -screenDiagAngle - Mathf.PI/2)))
			{
				float extra = screenHeight/2/distanceY * distanceX;
				Rect positionArrow = new Rect(screenWidth/2 - extra - arrow.width/2,
				                              screenHeight - arrow.width,
				                              arrow.width,
				                              arrow.height);
				GUIUtility.RotateAroundPivot(angle/Mathf.PI*180 - 90, new Vector2(positionArrow.x,positionArrow.y));
				GUI.Label(positionArrow,arrow);
			}
		}
	}
}
