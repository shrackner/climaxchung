﻿using UnityEngine;
using System.Collections;

public class CameraBehavior : MonoBehaviour {
	void Start ()
	{

	}
	void Update ()
	{
		//Smooth moves
		transform.position = new Vector3(
		transform.position.x + (GameObject.Find("catSprite").transform.position.x - transform.position.x)/15,
    	transform.position.y + (GameObject.Find("catSprite").transform.position.y - transform.position.y)/15,
	 	-10);

	}
}
