﻿using UnityEngine;
using System.Collections;

public class Yarn_Interaction : MonoBehaviour {
	public GameObject yarn;
	private bool hasYarn = true;
	private float power;
	private float mouseAngle;
	private float coefX;
	private float coefY;

	void Start ()
	{
		yarn.SetActive(false);
	}
	
	// Update is called once per frame
	void Update ()
	{
		//When mouse(right) is held, return ball and cancels power charging
		if(Input.GetMouseButton(1))
		{
			yarn.SetActive(false);
			hasYarn = true;
			power = 0;
		}

		//When mouse(left) is held down, charge
		if(Input.GetMouseButton(0))
		{
			if(!Input.GetMouseButton(1))
			{
				if(power <= 500)
				{
					power += Time.deltaTime * 1000;
				}
			}
			else
			{
				power = 0;
			}
		}

		//On mouse(left) release, shoot the ball in the direction of mouse based on power
		if(Input.GetMouseButtonUp(0))
		{
			if(hasYarn)
			{
				yarn.SetActive(true);
				hasYarn = false;
				mouseAngle = Mathf.Atan2(
					(Camera.main.ScreenToWorldPoint(Input.mousePosition).y - transform.position.y),
					(Camera.main.ScreenToWorldPoint(Input.mousePosition).x - transform.position.x));
				coefX = Mathf.Cos(mouseAngle);
				coefY = Mathf.Sin(mouseAngle);
				yarn.transform.position = transform.position + new Vector3(coefX, coefY);
				yarn.rigidbody.velocity = Vector3.zero;
				yarn.rigidbody.AddForce(power*coefX, power*coefY,0);
			}
			else
			{
				transform.position = yarn.transform.position + (new Vector3(0,1,0));
				yarn.SetActive(false);
				hasYarn = true;
			}
			power = 0;
		}
	}
}
