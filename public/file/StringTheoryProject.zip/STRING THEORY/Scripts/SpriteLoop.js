var numFrames:int = 1;
var currentFrame:int;
//var mat:Material;
var offset:float = 1/numFrames;


function Start () 
{
	//mat = renderer.material;
	currentFrame = 0;
	if(numFrames > 1)
	{
		while(true)
		{
			yield new WaitForSeconds(0.05);
			UpdateFrame();
		}
	}
}

function UpdateFrame () 
{
	++currentFrame;
	if(currentFrame >= numFrames) currentFrame = 0;
	
	renderer.material.SetTextureOffset("_MainTex", Vector2(currentFrame*offset,0));
	

}