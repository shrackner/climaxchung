none = 0
chooseName = 1
matchMaking = 2
game = 3
