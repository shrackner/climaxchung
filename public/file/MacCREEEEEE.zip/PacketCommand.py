# data = name
name = 0

# data = GameState
gameState = 1

# data = GameState, playerid
gameStart = 2

# data = loser
gameEnd = 3

# data = None
gameDisconnect = 4

# data = InputManager
inputManager = 5

# data = None
alive = 6
